import pandas as pd
import math
import heapq
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
import matplotlib.pyplot as plt


def perf_measure(y_actual, y_hat):
    TP = 0
    FP = 0
    TN = 0
    FN = 0

    for i in range(len(y_hat)): 
        if y_actual[i]==y_hat[i]==1:
           TP += 1
        if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
           FP += 1
        if y_actual[i]==y_hat[i]==0:
           TN += 1
        if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
           FN += 1

    return TP, FP, TN, FN




def calculate_distance(a,b):
	return (a-b)*(a-b)
	#return abs(a-b)

all_datasets=['RobotDataset/Robot1','RobotDataset/Robot2','Iris/Iris.csv']
x_axis=[]
y1_axis=[]
y2_axis=[]
y3_axis=[]
for K_parameter in range(1,20):
	
	print K_parameter
	for dataset_name in all_datasets:
		csv_reader= pd.read_csv(dataset_name, delimiter=' ',header=None)
		dataset = [list(x) for x in csv_reader.values]
		
		x_data=[]
		y_data=[]
		
		if(dataset_name=='RobotDataset/Robot1' or dataset_name=='RobotDataset/Robot2'):
			for i in dataset:
				y_data.append(i[1])
			
			for i in dataset:
				x_data.append(i[2:8])	
		else:
			csv_reader= pd.read_csv(dataset_name, delimiter=',',header=None)
			dataset = [list(x) for x in csv_reader.values]
			
			for i in dataset:
				y_data.append(i[4])
			
			for i in dataset:
				x_data.append(i[0:4])	
		
		x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20,random_state=42)
		y_pred=[]
		
		'''
		##if
		########################################################################
		from sklearn.neighbors import KNeighborsClassifier
		neigh = KNeighborsClassifier(n_neighbors=3)
		neigh.fit(x_train,y_train)
		
		y_pred=list(neigh.predict(x_test) )
		########################################################################
		'''
		##else
		########################################################################
		for i in range (0,len(x_test)):
			distances=[]
			for j in range(0,len(x_train)):
				d=0
				for k in range(0,len(x_train[0])):
					d+=calculate_distance(x_train[j][k],x_test[i][k])
				d=math.sqrt(d)
				distances.append((d,j))
			heapq.heapify(distances)
			res=heapq.nsmallest(K_parameter,distances)
			zero=0
			one=0
			two=0
			if(dataset_name=='RobotDataset/Robot1' or dataset_name=='RobotDataset/Robot2'):
				for l in res:
					if y_train[l[1]]==0:
						zero+=1
					else:
						one+=1
				if zero>one:
					y_pred.append(0)
				else:
					y_pred.append(1)
			else:
				for l in res:
					if y_train[l[1]]=='Iris-setosa':
						zero+=1
					elif y_train[l[1]]=='Iris-virginica':
						one+=1
					else:
						two+=1
				if zero>=one and zero >two:
					y_pred.append('Iris-setosa')
				elif one>=zero and one>two:
					y_pred.append('Iris-virginica')
				elif two>=one and two>zero:
					y_pred.append('Iris-versicolor')
		########################################################################
		
		if(dataset_name!="Iris/Iris.csv"):
			TP,FP,TN,FN=perf_measure(y_test,y_pred)	
			accuracy=float(TP+TN)/(TP+TN+FP+FN)
			recall=float(TP)/(TP+FN)
			precision=float(TP)/(TP+FP)
			f1=2*precision*recall/(precision+recall)
			print"Dataset : ",dataset_name
			print "Accuracy : ",accuracy
			if(dataset_name=='RobotDataset/Robot1'):
				y1_axis.append(accuracy)
			else:
				y2_axis.append(accuracy)
		else:
			print"Dataset : ",dataset_name
			print "Accuracy : ",accuracy_score(y_test,y_pred)
			y3_axis.append(accuracy_score(y_test,y_pred))
		
	x_axis.append(K_parameter)
		    
plt.figure()
plt.title("Hello")

plt.plot(x_axis,y1_axis)
plt.title("Robot1 - K on Accuracy (Distance:Euclidean)",fontsize=8)
plt.ylabel("Accuracy")
plt.xlabel("K")
plt.show()
#plt.savefig("robot1_manhattan")


plt.figure()
plt.plot(x_axis,y2_axis,color='b')
plt.title("Robot2 K on Accuracy (Distance:Euclidean)",fontsize=8)
plt.ylabel("Accuracy")
plt.xlabel("K")
plt.show()
#plt.savefig("robot2_manhattan")


plt.figure()
plt.plot(x_axis,y3_axis)
plt.title("Iris K on Accuracy (Distance:Euclidean)",fontsize=8)
plt.ylabel("Accuracy")
plt.xlabel("K")
#plt.savefig("iris_manhattan")

plt.show()
	
	