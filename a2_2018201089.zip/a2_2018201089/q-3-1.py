import sys
import pandas as pd
import math
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,r2_score
import matplotlib.pyplot as plt

def calculate_func(hypo,x):
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return temp

if __name__=="__main__":	
	csv_reader= pd.read_csv('AdmissionDataset/data.csv', delimiter=',')
	dataset = [list(x) for x in csv_reader.values]
	for i in range(len(dataset)):
		dataset[i][1]/=float(340)
		dataset[i][2]/=float(120)
		dataset[i][3]/=float(5)
		dataset[i][4]/=float(5)
		dataset[i][5]/=float(10)
	
	x_data=[]
	y_data=[]
	for i in dataset:
		y_data.append(i[8])
		x_data.append(i[1:8])
	
	x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20)
	
	parameters=[]
	temp_parameters=[]
	start_val=0
	for i in range(0,len(x_train[0])+1):
		parameters.append(start_val)
		temp_parameters.append(start_val)
	
	itr=1
	max_itr=500
	m=len(x_train)
	alpha=0.0008
	
	x_axis=[]
	y_axis1=[]
	y_axis2=[]
	y_axis3=[]
	
	while(itr<max_itr):
		
		#print parameters
		for i in range(0,len(x_train[0])+1):
			summation=0
			for j in range(0,len(x_train)):
				if(i==0):
					summation+=(calculate_func(parameters,x_train[j])-y_train[j])
				else:
					summation+=((calculate_func(parameters,x_train[j])-y_train[j])*x_train[j][i-1])
			temp_parameters[i]=parameters[i]-alpha*(1/float(m))*summation
			
		for i in range(0,len(x_train[0])+1):
			parameters[i]=temp_parameters[i]
		
		y_pred=[]
		x_axis.append(itr)
		error1=0
		error2=0
		error3=0
		for j in range(0,len(x_test)):
			xx=calculate_func(parameters,x_test[j])
			error1+=(-xx+y_test[j])**2
			error2+=abs(-xx+y_test[j])
			error3+=abs(-xx+y_test[j])/abs(y_test[j])
			
			y_pred.append(xx)
		
		y_axis1.append(error1/(m))
		y_axis2.append(error2/(m))
		y_axis3.append(100*error3/(m))
		itr+=1	
	print "Parameters : "
	for jj in range(len(parameters)):
		print "Theta ",jj,parameters[jj]
	print "r2 score : ",r2_score(y_test,y_pred)
	y_pred=[]
	x_test=[]
	csv_reader= pd.read_csv(sys.argv[1], delimiter=',')
	test_data = [list(x) for x in csv_reader.values]
	
	for i in range(len(test_data)):
		test_data[i][1]/=float(340)
		test_data[i][2]/=float(120)
		test_data[i][3]/=float(5)
		test_data[i][4]/=float(5)
		test_data[i][5]/=float(10)
	for i in test_data:
		x_test.append(i[1:8])
	

	for i in range(len(x_test)):
		print "Predicted Value : ",calculate_func(parameters,x_test[i])#,"Actual Value : ",y_test[i]	
		y_pred.append(calculate_func(parameters,x_test[i]))
		
	
	
	'''
	plt.figure()
	plt.plot(x_axis,y_axis1)
	plt.title("Error Vs Number Of Iterations")
	plt.ylabel("Error (Mean Squared Error)")
	plt.xlabel("Number Of Iterations")
	plt.savefig("linear_regression_mean_square")
	plt.show()
		
	
	plt.figure()
	plt.plot(x_axis,y_axis2)
	plt.title("Error Vs Number Of Iterations")
	plt.ylabel("Error (Mean Absolute Error)")
	plt.xlabel("Number Of Iterations")
	plt.savefig("linear_regression_mean_absolute")
	plt.show()
		
	
	plt.figure()
	plt.plot(x_axis,y_axis3)
	plt.title("Error Vs Number Of Iterations")
	plt.ylabel("Error (Mean Absolute Percentage Error)")
	plt.xlabel("Number Of Iterations")
	plt.savefig("linear_regression_mean_absolute_percentage")
	plt.show()
	'''


	
	