import sys
import pandas as pd
import math
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
mean_list={}
std_list={}




def perf_measure(y_actual, y_hat):
    TP = 0
    FP = 0
    TN = 0
    FN = 0

    for i in range(len(y_hat)): 
        if y_actual[i]==y_hat[i]==1:
           TP += 1
        if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
           FP += 1
        if y_actual[i]==y_hat[i]==0:
           TN += 1
        if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
           FN += 1

    return TP, FP, TN, FN


def populate_probabilities(uniques,positive_x_train,negative_x_train):
	posi_len=len(positive_x_train)
	negi_len=len(negative_x_train)
	global discrete_attributes
	probabilities={}
	for i in discrete_attributes:
		attribute_dict={}
		for j in uniques[i]:
			attribute_value_dict={}
			count=0
			for k in positive_x_train:
				if(k[i]==j):
					count+=1;
			attribute_value_dict[1]=float(count)/posi_len
			count=0
			for k in negative_x_train:
				if(k[i]==j):
					count+=1;
			attribute_value_dict[0]=float(count)/negi_len
			
		
			attribute_dict[j]=attribute_value_dict
		probabilities[i]=attribute_dict
	return probabilities

def generate_uniques(positive_x_train,negative_x_train):
	global discrete_attributes
	uniques={}
	for i in discrete_attributes:
		li=set()
		for j in positive_x_train+negative_x_train:
			li.add(j[i])
		uniques[i]=list(li)
	return uniques		
	
	


def populate_mean_stddev(positive_x_train,negative_x_train):
	global continuous_attributes
	global mean_list
	global std_list
	
	
	for i in continuous_attributes:
		mean_of_attribute={}
		std_of_attribute={}
		
		##for negative
		mean=0
		stddev=0
		for j in negative_x_train:
			mean+=j[i]
		mean=float(mean)/len(negative_x_train)
		
		for j in negative_x_train:
			stddev+=(j[i]-mean)**2
		stddev=float(stddev)/(len(negative_x_train)-1)
		stddev=math.sqrt(stddev)
		mean_of_attribute[0]=mean
		std_of_attribute[0]=stddev
		
		##for positive
		mean=0
		stddev=0
		for j in positive_x_train:
			mean+=j[i]
		mean=float(mean)/len(positive_x_train)
		
		for j in positive_x_train:
			stddev+=(j[i]-mean)**2
		stddev=float(stddev)/(len(positive_x_train)-1)
		stddev=math.sqrt(stddev)
		mean_of_attribute[1]=mean
		std_of_attribute[1]=stddev
		
		mean_list[i]=mean_of_attribute
		std_list[i]=std_of_attribute





csv_reader= pd.read_csv('LoanDataset/data.csv', delimiter=',',header=None)
dataset = [list(x) for x in csv_reader.values]
dataset=dataset[1:]

discrete_attributes=[3,6,8,9,10,11]
continuous_attributes=[0,1,2,4,5,7]

mean_list={}
std_dev={}



x_data=[]
y_data=[]


for i in dataset:
	y_data.append(i[9])

for i in dataset:
	temp=i
	del(temp[9])
	del(temp[0])
	x_data.append(temp)	

x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2)


positive_x_train=[]
negative_x_train=[]


for i in range (0,len(y_train)):
	if(y_train[i]==0):
		negative_x_train.append(x_train[i])
	else:
		positive_x_train.append(x_train[i])


populate_mean_stddev(positive_x_train,negative_x_train)
uniques=generate_uniques(positive_x_train,negative_x_train)
probabilities=populate_probabilities(uniques,positive_x_train,negative_x_train)

def calculate_discrete_function(aatr,val,type_):
	global mean_list
	global std_list
	
	f=(1/(2*math.pi*std_list[j][type_]))*(math.e**(-1*((val-mean_list[j][type_])**2)/(std_list[j][type_]**2)))
	return f


y_pred=[]
for i in x_test:
	neg_prob=1
	pos_prob=1
	try:
		for j in range(0,len(i)):
			if j in continuous_attributes:
				neg_prob*=calculate_discrete_function(j,i[j],0)		
				pos_prob*=calculate_discrete_function(j,i[j],1)		
			else:
				#print j,i[j],0
				neg_prob*=probabilities[j][i[j]][0]
				pos_prob*=probabilities[j][i[j]][1]
	
		yes_percent=pos_prob/(pos_prob+neg_prob)
		no_percent=neg_prob/(pos_prob+neg_prob)
		if(yes_percent>no_percent):
			y_pred.append(1)
		else:
			y_pred.append(0)
	except:
		y_pred.append(0)
TP,FP,TN,FN=perf_measure(y_test,y_pred)	
accuracy=float(TP+TN)/(TP+TN+FP+FN)
recall=float(TP)/(TP+FN)
precision=float(TP)/(TP+FP)
f1=2*precision*recall/(precision+recall)

print "Accuracy : ",accuracy
print "Recall : ",recall
print "Precision : ",precision
print "F1 : ",f1
print "\n\n"	


################################

csv_reader= pd.read_csv(sys.argv[1], delimiter=',',header=None)
dataset = [list(x) for x in csv_reader.values]
final_x_test=[]
for i in dataset:
	temp=i
	del(temp[0])
	final_x_test.append(temp)

y_pred=[]
for i in final_x_test:
	neg_prob=1
	pos_prob=1
	try:
		for j in range(0,len(i)):
			if j in continuous_attributes:
				neg_prob*=calculate_discrete_function(j,i[j],0)		
				pos_prob*=calculate_discrete_function(j,i[j],1)		
			else:
				#print j,i[j],0
				neg_prob*=probabilities[j][i[j]][0]
				pos_prob*=probabilities[j][i[j]][1]
	
		yes_percent=pos_prob/(pos_prob+neg_prob)
		no_percent=neg_prob/(pos_prob+neg_prob)
		if(yes_percent>no_percent):
			y_pred.append(1)
		else:
			y_pred.append(0)
	except:
		y_pred.append(0)

print "Predictions"
for i in y_pred:
    print i




