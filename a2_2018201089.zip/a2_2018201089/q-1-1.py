import pandas as pd
import math
import heapq
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
import sys


def perf_measure(y_actual, y_hat):
	TP = 0
	FP = 0
	TN = 0
	FN = 0

	for i in range(len(y_hat)): 
		if y_actual[i]==y_hat[i]==1:
		   TP += 1
		if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
		   FP += 1
		if y_actual[i]==y_hat[i]==0:
		   TN += 1
		if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
		   FN += 1

	return TP, FP, TN, FN




def calculate_distance(a,b):
	return (a-b)*(a-b)

K_parameter=3
all_datasets=['RobotDataset/Robot1','RobotDataset/Robot2','Iris/Iris.csv']

for iii in range(1):
	print "Enter Dataset Name (valid choices : 'RobotDataset/Robot1','RobotDataset/Robot2','Iris/Iris.csv') "
	dataset_name=raw_input("Enter Dataset Name : ")
	
	x_data=[]
	y_data=[]
	
	if(dataset_name=='RobotDataset/Robot1' or dataset_name=='RobotDataset/Robot2'):
		csv_reader= pd.read_csv(dataset_name, delimiter=' ',header=None)
		dataset = [list(x) for x in csv_reader.values]
	
		for i in dataset:
			y_data.append(i[1])
		
		#############################################
		for i in dataset:
			x_data.append(i[2:8])	
	else:
		csv_reader= pd.read_csv(dataset_name, delimiter=',',header=None)
		dataset = [list(x) for x in csv_reader.values]
		
		for i in dataset:
			y_data.append(i[4])
		
		for i in dataset:
			x_data.append(i[0:4])	
	
	x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20)
	y_pred=[]
		
		
		
	
	
	
	'''
	##if
	########################################################################
	from sklearn.neighbors import KNeighborsClassifier
	neigh = KNeighborsClassifier(n_neighbors=3)
	neigh.fit(x_train,y_train)
	
	y_pred=list(neigh.predict(x_test) )
	########################################################################
	'''
	##else
	########################################################################
	for i in range (0,len(x_test)):
		distances=[]
		for j in range(0,len(x_train)):
			d=0
			for k in range(0,len(x_train[0])):
				d+=calculate_distance(x_train[j][k],x_test[i][k])
			d=math.sqrt(d)
			distances.append((d,j))
		heapq.heapify(distances)
		res=heapq.nsmallest(K_parameter,distances)
		zero=0
		one=0
		two=0
		if(dataset_name=='RobotDataset/Robot1' or dataset_name=='RobotDataset/Robot2'):
			for l in res:
				if y_train[l[1]]==0:
					zero+=1
				else:
					one+=1
			if zero>one:
				y_pred.append(0)
			else:
				y_pred.append(1)
		else:
			for l in res:
				if y_train[l[1]]=='Iris-setosa':
					zero+=1
				elif y_train[l[1]]=='Iris-virginica':
					one+=1
				else:
					two+=1
			if zero>one and zero >two:
				y_pred.append('Iris-setosa')
			elif one>zero and one>two:
				y_pred.append('Iris-virginica')
			elif two>one and two>zero:
				y_pred.append('Iris-versicolor')
	########################################################################
	
	if(dataset_name!="Iris/Iris.csv"):
		TP,FP,TN,FN=perf_measure(y_test,y_pred)	
		accuracy=float(TP+TN)/(TP+TN+FP+FN)
		recall=float(TP)/(TP+FN)
		precision=float(TP)/(TP+FP)
		f1=2*precision*recall/(precision+recall)
		print"Dataset : ",dataset_name
		print "Accuracy : ",accuracy
		print "Recall : ",recall
		print "Precision : ",precision
		print "F1 : ",f1
		print "\n\n"
	else:
		print"Dataset : ",dataset_name
		print "Accuracy : ",accuracy_score(y_test,y_pred)
		print "Recall : ",recall_score(y_test,y_pred,average='weighted')
		print "Precision : ",precision_score(y_test,y_pred,average='weighted')
		print "F1 : ",f1_score(y_test,y_pred,average='weighted')
		print "\n\n"
		
	final_x_test=[]
	y_pred=[]
	if(dataset_name=="Iris/Iris.csv"):
		csv_reader=pd.read_csv(sys.argv[1], delimiter=',',header=None)
		dataset = [list(x) for x in csv_reader.values]
		for i in dataset:
			final_x_test.append(i[0:4])
		for i in range (0,len(final_x_test)):
			distances=[]
			for j in range(0,len(x_train)):
				d=0
				for k in range(0,len(x_train[0])):
					d+=calculate_distance(x_train[j][k],final_x_test[i][k])
				d=math.sqrt(d)
				distances.append((d,j))
			heapq.heapify(distances)
			res=heapq.nsmallest(K_parameter,distances)
			zero=0
			one=0
			two=0
			
			for l in res:
				if y_train[l[1]]=='Iris-setosa':
					zero+=1
				elif y_train[l[1]]=='Iris-virginica':
					one+=1
				else:
					two+=1
			if zero>one and zero >two:
				y_pred.append('Iris-setosa')
			elif one>zero and one>two:
				y_pred.append('Iris-virginica')
			elif two>one and two>zero:
				y_pred.append('Iris-versicolor')
			
		print "Predictions"
		for jj in y_pred:
			print jj
	else:
		csv_reader= pd.read_csv(sys.argv[1], delimiter=' ',header=None)
		dataset = [list(x) for x in csv_reader.values]
		###########################################
		for i in dataset:
			final_x_test.append(i[2:8])
		###########################################
		print final_x_test
		for i in range (0,len(final_x_test)):
			distances=[]
			for j in range(0,len(x_train)):
				d=0
				for k in range(0,len(x_train[0])):
					d+=calculate_distance(x_train[j][k],final_x_test[i][k])
				d=math.sqrt(d)
				distances.append((d,j))
			heapq.heapify(distances)
			res=heapq.nsmallest(K_parameter,distances)
			zero=0
			one=0
			two=0
			for l in res:
					if y_train[l[1]]==0:
						zero+=1
					else:
						one+=1
			if zero>one:
				y_pred.append(0)
			else:
				y_pred.append(1)
		
		print "Predictions"
		for jj in y_pred:
			print jj