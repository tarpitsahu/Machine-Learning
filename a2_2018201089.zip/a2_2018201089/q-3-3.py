
import pandas as pd
import math
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score
import matplotlib.pyplot as plt

def calculate_func(hypo,x):
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return temp

def new_calculate_function(hypo,x,i):
    return hypo[0] + hypo[i]*x


csv_reader= pd.read_csv('AdmissionDataset/data.csv', delimiter=',')
dataset = [list(x) for x in csv_reader.values]
for i in range(len(dataset)):
	dataset[i][1]/=float(340)
	dataset[i][2]/=float(120)
	dataset[i][3]/=float(5)
	dataset[i][4]/=float(5)
	dataset[i][5]/=float(10)

x_data=[]
y_data=[]
for i in dataset:
	y_data.append(i[8])
	x_data.append(i[1:8])
x_name=['GREScore','TOEFLScore','UniversityRating','SoP','UG GPA','ResearchExp']
x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20)

parameters=[]
temp_parameters=[]
start_val=0
for i in range(0,len(x_train[0])+1):
	parameters.append(start_val)
	temp_parameters.append(start_val)

itr=1
max_itr=150
m=len(x_train)
alpha=0.0008

while(itr<max_itr):
	
	
	for i in range(0,len(x_train[0])+1):
		summation=0
		for j in range(0,len(x_train)):
			if(i==0):
				summation+=(calculate_func(parameters,x_train[j])-y_train[j])
			else:
				summation+=((calculate_func(parameters,x_train[j])-y_train[j])*x_train[j][i-1])
		temp_parameters[i]=parameters[i]-alpha*(1/float(m))*summation
		
	for i in range(0,len(x_train[0])+1):
		parameters[i]=temp_parameters[i]
	
	
	
	
	itr+=1	
print "Parameters : "
for jj in range(len(parameters)):
		print "Theta ",jj,parameters[jj]
fig=plt.figure()
plt.title("Hello")
cs=['r','g','y','b','orange','purple']
for j in range(len(x_name)):
	x_axis=[]
	y_axis=[]
	for i in range(len(x_test)):	
		x_axis.append(x_test[i][j])
		y_axis.append(new_calculate_function(parameters,x_test[i][j],j)-y_test[i])
		
	plt.subplot(2, 3,j+1)
	plt.scatter(x_axis,y_axis,s=9,color=cs[j])
	plt.title("Residual Vs "+x_name[j])
	plt.ylabel("Residual")
	plt.xlabel(x_name[j])

fig.tight_layout()
	
plt.show()
	
