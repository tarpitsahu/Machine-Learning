import matplotlib.pyplot as plt



GMM_purity=[0.86,0.41,1,1,1]
k_purity=[0.87,0.95,0.89,0.41,0.79]
h_purity=[1,1,1,1,1]

x=[1,2,3,4,5]

axes = plt.gca()
axes.set_ylim([0,1])
plt.xticks(x,["Cluster 1","Cluster 2","Cluster 3","Cluster 4","Cluster 5"])
plt.bar(x,h_purity)
plt.xlabel("Cluster")
plt.ylabel("Purity")
plt.title("Hierarchical Clustering")
plt.savefig("H")