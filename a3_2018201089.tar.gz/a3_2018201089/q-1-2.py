import pandas as pd
import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as plt
import random
from sklearn.cluster import KMeans
import pickle

dataset_name="intrusion_detection_new/data.csv"
csv_reader= pd.read_csv(dataset_name, delimiter=',')
#X = [list(x[0:14]) for x in csv_reader.values]
Y = [x[29] for x in csv_reader.values]
#X=X[1000:2000]
#Y=Y[1000:2000]
inputx=open('reduced_x_new','rb')
X=pickle.load(inputx)
inputx.close()



K=5

def columnize_dataset(dataset):
    X=[]
    
    
    for i in range(len(dataset[0])):
        t=[row[i] for row in dataset]
        X.append(t)
    
    return X


def initialize_centroids(K):
    centroids=[]
    
    for i in range(K):
        x=random.randint(0,10)
        y=random.randint(0,100)
        
        
        
        centroids.append([x,y])
        centroids=[[0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,],[0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3,0.3],[0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5],[0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7],[0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9]]
    return centroids


centroids=initialize_centroids(K)
member=[None]*len(Y)
for i in range(len(Y)):
    maxi=9999999
    cluster=0
    for j in range(K):
        d=0
        for kk in range(14):
            d+=(X[i][kk]-centroids[j][kk])**2
        if(d<maxi):
            maxi=d
            cluster=j
    member[i]=cluster
  
'''
Pitfall
mean=[[0,0]]*K
count=[0]*K
'''
'''
kmeans = KMeans(n_clusters=K, random_state=0).fit(X)
print kmeans.cluster_centers_
'''




for itr in range(0,10):
    mean=[]
    count=[]
    for i in range(K):
        mean.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0])
        count.append(0)
    
    
    for i in range(len(Y)):
        mean[member[i]][0]=mean[member[i]][0]+X[i][0];
        mean[member[i]][1]=mean[member[i]][1]+X[i][1];
        count[member[i]]=count[member[i]]+1
        
        
    for i in range(K):
        for kkk in range(14):
            try:
                mean[i][kkk]=float(mean[i][kkk])/count[kkk]
            except:
                mean[i][kkk]=0
                
            centroids[i][kkk]=mean[i][kkk]
        
    for i in range(len(Y)):
        maxi=9999999
        cluster=0
        for j in range(K):
            d=0
            for kk in range(14):
                d+=(X[i][kk]-centroids[j][kk])**2
            if(d<maxi):
                maxi=d
                cluster=j
        member[i]=cluster
    #for k in range(K):
    #   for i in range():
    
    
for j in range(K):
    count={'dos':0,'normal':0,'probe':0,'r2l':0,'u2r':0}
    
    for i in range(len(member)):
        if(member[i]==j):
            count[Y[i]]+=1
        
    print "Purity of Cluster",j,":", max(count.values())/float(sum(count.values()))
    print "Cluster Count : ",count
    print ""    
    
    
    
    
