import pandas as pd
from sklearn.cluster import AgglomerativeClustering
import pickle
dataset_name="intrusion_detection_new/data.csv"
csv_reader= pd.read_csv(dataset_name, delimiter=',')
#X = [list(x[0:2]) for x in csv_reader.values]
Y = [x[29] for x in csv_reader.values]
Y=Y[:18000]
K=5

inputx=open('reduced_x_new','rb')
X=pickle.load(inputx)
X=X[:18000]
inputx.close()



hc = AgglomerativeClustering(linkage='single',n_clusters=K)
hc.fit(X,y=Y)
member=hc.fit_predict(X)

for j in range(K):
        count={'dos':0,'normal':0,'probe':0,'r2l':0,'u2r':0}
        
        for i in member:
            if i==j:
                count[Y[i]]+=1
        print count        
        print "Purity of Cluster",j,":", max(count.values())/float(sum(count.values()))


