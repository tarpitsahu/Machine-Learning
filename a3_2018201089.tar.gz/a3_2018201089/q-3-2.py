import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split 

learning_rate = 0
iterations = 0
threshold = 0

def set_param():
    global learning_rate
    global iterations
    global threshold
    learning_rate = 0.01
    iterations = 1000
    threshold = 0.5
    
set_param()
df=pd.read_csv("wine-quality/data.csv",delimiter=',')

X = df.drop(['quality'],axis=1)
Y = df['quality']

X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size = 0.2)
X_train = (X_train - X_train.mean())/X_train.std()
X_test = (X_test - X_test.mean())/X_test.std()




ones = np.ones([X_train.shape[0],1])
X_train = np.concatenate((ones,X_train),axis=1)
X_train.shape




theta = np.zeros([15,12])
theta.shape



def func(z):
    return 1 / (1 + np.exp(-z))



def gradient_decent(X_train,Y_train,theta,alpha,iterations):
    for i in range(iterations):
        h = func(np.dot(X_train,theta.T))
        theta = theta - (alpha/len(X_train)) * np.sum(X_train * (h - Y_train), axis=0)
    return theta



x=0
for i in range(4,9):
    for j in range(i+1,10):
        theta1 = np.zeros([1,12])
        
        Xcopy = []
        Ycopy = []
        W = np.array(Y_train)

        for k in range(len(W)):
            if W[k] == j or W[k]==i:
                Xcopy.append(X_train[k])
                if W[k] == i:
                    Ycopy.append(1)
                else:
                    Ycopy.append(0)
        
        Xcopy = np.array(Xcopy)
        Ycopy = np.array(Ycopy)
        Ycopy = Ycopy.reshape((len(Ycopy),1))

        theta[x]=gradient_decent(Xcopy,Ycopy,theta1,learning_rate,iterations)
        x = x + 1



y_pred = []
for index,rows in X_test.iterrows():

    rows = list(rows)
    counts = {}
    label = 0
    for i in range(4,10):
        counts[i]=0
    max_h = 0
    c = 0
    for a in range(4,9):
        for b in range(a+1,10):
            y = 0
            for i in range(len(rows)):
                y = y + rows[i]*theta[c][i+1]
            y = y + theta[c][0]
            y = func(y)
            c = c + 1
            if y >= threshold:
                counts[a]=counts[a]+1
            else:
                counts[b]=counts[b]+1

    for i in range(4,10):
        if(counts[i]>=max_h):
            max_h=counts[i]
            label=i
    y_pred.append(label)




print "Accuracy",((y_pred == Y_test).mean()*100)





