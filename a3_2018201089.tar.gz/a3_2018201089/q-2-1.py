import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score,precision_score,recall_score

from sklearn.model_selection import train_test_split
import math
threshold=0.70
dataset_name="AdmissionDataset/data.csv"
csv_reader= pd.read_csv(dataset_name, delimiter=',')
X = [list(x[1:7]) for x in csv_reader.values]
Y = [x[8] for x in csv_reader.values]


def calculate_func(hypo,x):
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return 1.0/(1+math.e**(-temp))


def normalize_dataset(X,Y):
    global threshold
    for i in range(len(X[0])):
        mean=0.0
        std=0.0
        for j in range(len(X)):
            mean+=X[j][i]
        mean=mean/(len(X))
        
        for j in range(len(X)):
            std+=(X[j][i]-mean)**2
        std=std**0.5
            
            
            
        for j in range(len(X)):
            X[j][i]=(X[j][i]-mean)/std
          
        for j in range(len(X)):
            if(Y[j]>threshold):
                Y[j]=1
            else:
                Y[j]=0
            
    return X,Y

X,Y= normalize_dataset(X,Y)

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.20,random_state=42)
    

parameters=[]
temp_parameters=[]
start_val=0
for i in range(0,len(x_train[0])+1):
	parameters.append(start_val)
	temp_parameters.append(start_val)

itr=1
max_itr=1000
m=len(x_train)
alpha=0.9

while(itr<max_itr):
	
	
	for i in range(0,len(x_train[0])+1):
		summation=0
		for j in range(0,len(x_train)):
			if(i==0):
				summation+=(calculate_func(parameters,x_train[j])-y_train[j])
			else:
				summation+=((calculate_func(parameters,x_train[j])-y_train[j])*x_train[j][i-1])
		temp_parameters[i]=parameters[i]-alpha*(1/float(m))*summation
		
	for i in range(0,len(x_train[0])+1):
		parameters[i]=temp_parameters[i]
	
	
	
	itr+=1	
print "Parameters : "
for jj in range(len(parameters)):
	print "Theta ",jj,parameters[jj]

y_pred=[]
for i in x_test:
    t=calculate_func(parameters,i)
    if(t>threshold):
        y_pred.append(1)
    else:
        y_pred.append(0)
        
print accuracy_score(y_test,y_pred)
print precision_score(y_test,y_pred)
print recall_score(y_test,y_pred)

