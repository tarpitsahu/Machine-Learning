import pandas as pd
import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as plt
import random
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import train_test_split
import pickle
dataset_name="intrusion_detection_new/data.csv"
csv_reader= pd.read_csv(dataset_name, delimiter=',')
#X = [list(x[0:2]) for x in csv_reader.values]
Y = [x[29] for x in csv_reader.values]
K=5
#X_train, X_test, y_train, y_test = train_test_split(X,Y,test_size=0.20, random_state=42)
inputx=open('reduced_x_new','rb')
X=pickle.load(inputx)
inputx.close()


gmm = GaussianMixture(n_components=K)
gmm.fit(X,y=Y)

member=gmm.predict(X)

for j in range(K):
    count={'dos':0,'normal':0,'probe':0,'r2l':0,'u2r':0}
    
    for i in range(len(member)):
        if(member[i]==j):
            count[Y[i]]+=1
        
    print "Purity of Cluster",j,":", max(count.values())/float(sum(count.values()))
    print "Cluster Count : ",count
    print ""    
        
    
