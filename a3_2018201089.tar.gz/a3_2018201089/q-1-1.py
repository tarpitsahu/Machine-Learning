import pandas as pd
import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as plt

import pickle


dataset_name="intrusion_detection_new/data.csv"
csv_reader= pd.read_csv(dataset_name, delimiter=',')
dataset = [list(x) for x in csv_reader.values]
#dataset =dataset[1:100]

X=[]
Y=[]
for i in dataset:
    X.append(i[0:len(i)-1])
    Y.append(i[len(i)-1])
    
    


def columnize_dataset(dataset):
    X=[]
    
    
    for i in range(len(dataset[0])):
        t=[row[i] for row in dataset]
        X.append(t)
    
    return X

def compute_mean(X):
    mean=[0.0]*len(X[0])
    std=[0.0]*len(X[0])
    
    
    for i in xrange(len(X)):
        
        for j in xrange(len(X[0])):
          mean[j]+=X[i][j]
    
    for i in range(len(mean)):
        mean[i]=mean[i]/len(X)
    
    for i in xrange(len(X)):
        for j in xrange(len(X[0])):
          std[j]+=(X[i][j]-mean[j])**2
          
    for i in range(len(mean)):
        std[i]=std[i]/len(X)
        std[i]=std[i]**0.5
    
    
    
    return mean,std

def normalize(X,mean,std):
    for i in xrange(len(X)):
        for j in range(len(X[0])):
            #X[i][j]=(X[i][j]-mean[j])
            X[i][j]=(X[i][j]-mean[j])/std[j]
    return X
        

mean,std=compute_mean(X)
X=normalize(X,mean,std)
Q=np.matmul(np.transpose(X),X)
Q=(float(1)/len(X))*Q
eigen_values,eigen_vectors = LA.eig(Q)    

results=[]

for i in range(len(eigen_values)):
    results.append((eigen_values[i],eigen_vectors[i],i))
    
results.sort(reverse=True)

cum_sum=[]
for i in range(29):
    cum_sum.append(0)
    
for i in range(1,29):
    cum_sum[i]=cum_sum[i-1]+results[i][0]
maxi=cum_sum[-1]

for i in range(1,29):
    cum_sum[i]=cum_sum[i]/maxi

tot = sum(eigen_values)
var_exp = [(i / tot)*100 for i in sorted(eigen_values,reverse=True)]
x=range(0,29)
plt.bar(x,var_exp)
plt.show()

chosen_vectors=[]
chosen_values=[]

for i in range(0,14):
    chosen_values.append(results[i][0])
    chosen_vectors.append(results[i][1])

chosen_vectors=np.array(chosen_vectors)
chosen_vectors=np.transpose(chosen_vectors)

    
X_NEW=np.matmul(X,chosen_vectors)
output = open('reduced_x_new', 'wb')
pickle.dump(X_NEW,output)
output.close()



print "From the above graph, it is clear that Feature 0 to 13 are the best."


