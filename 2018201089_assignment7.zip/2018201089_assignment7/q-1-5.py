
import sys
import pandas as pd
import math
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,r2_score
import matplotlib.pyplot as plt
def split(a, n):
    k, m = divmod(len(a), n)
    return (a[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in xrange(n))


def get_error(y_test,y_pred):
    e=0
    for i in range(len(y_test)):
        e=e+(y_test[i]-y_pred[i])**2
    e=e/float(len(y_test))
    return e

def normalize_dataset(dataset):
    num_of_f=len(dataset[0])
    mean=[0]*num_of_f
    stddev=[0]*num_of_f
    for line in dataset:
        for j in range(len(line)):
            mean[j]+=line[j]
    
    for i in range(len(mean)):
        mean[i]=mean[i]/float(len(dataset))
    
    for line in dataset:
        for j in range(len(line)):
            stddev[j]+=(line[j]-mean[j])**2
    
    for i in range(len(mean)):
        stddev[i]=(stddev[i]/float(len(dataset)))**0.5
    
    for i in range(len(dataset)):
        for j in range(len(dataset[0])):
            dataset[i][j]=(dataset[i][j]-mean[j])/float(stddev[j])
    
    return dataset
    

def calculate_func(hypo,x):
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return temp

if __name__=="__main__":	
	csv_reader= pd.read_csv('AdmissionDataset/data.csv', delimiter=',')
	dataset = [list(x) for x in csv_reader.values]
	dataset=normalize_dataset(dataset)
	x_axis=[]
	y_axis_error=[]
	y_axis_r2=[]
	for KK in range(1):##############for K in range (2,20):
		avg_=0
		error=0
		x_data=[]
		y_data=[]
		for i in dataset:
			y_data.append(i[8])
			x_data.append(i[1:8])
		
		X, x_test_final, Y, y_test_final = train_test_split(x_data, y_data, test_size=0.20)
		K=len(X)  ############## delete
		X=list(split(X,K))
		Y=list(split(Y,K))
		x_train=[]
		x_test=[]
		y_train=[]
		y_test=[]
        
		for i in range(K):
			x_train=[]
			x_test=[]
			y_train=[]
			y_test=[]
			for j in range(len(X)):
				if(i==j):
					x_test.extend(X[j])
					y_test.extend(Y[j])
				else:
					x_train.extend(X[j])
					y_train.extend(Y[j])

			itr=1
			max_itr=50
			m=len(x_train)
			alpha=0.0008
			
			
			
			
			
			
			parameters=[0.5]*(len(x_train[0])+1)    
			temp_parameters=list(np.random.rand(len(x_train[0])+1))
			   
			while(itr<max_itr):
				
				#print "==",lambda_,"==",itr      
				for i in range(0,len(x_train[0])+1):
					summation=0
				
					for j in range(0,len(x_train)):
						if(i==0):
							summation+=(calculate_func(parameters,x_train[j])-y_train[j])
							
							
						else:
							summation+=((calculate_func(parameters,x_train[j])-y_train[j])*x_train[j][i-1])
					
					temp_parameters[i]=parameters[i]-alpha*(1/float(m))*(summation)		
					
		  
				for ii in range(0,len(x_train[0])+1):
						parameters[ii]=temp_parameters[ii]
				
				
				itr+=1
		        
			#print parameters
			y_pred=[]
			for i in x_test:
				y_pred.append(calculate_func(parameters,i))    
			print "K=",K," ",r2_score(y_test,y_pred)
			print "K=",K," ",get_error(y_test,y_pred)            
			avg_+=r2_score(y_test,y_pred)
			error+=get_error(y_test,y_pred)            
		print "K=",K," Aveg R2Score",avg_/float(K)            
		print "K=",K," Aveg Error",error/float(K)                    
		x_axis.append(K)
		y_axis_error.append(error/float(K))
		y_axis_r2.append(avg_/float(K))