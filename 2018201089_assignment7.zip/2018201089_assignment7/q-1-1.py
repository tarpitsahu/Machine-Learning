
import sys
import pandas as pd
import math
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,r2_score
import matplotlib.pyplot as plt

def get_error(y_test,y_pred):
    e=0
    for i in range(len(y_test)):
        e=e+(y_test[i]-y_pred[i])**2
    e=e/float(len(y_test))
    return e


def normalize_dataset(dataset):
    num_of_f=len(dataset[0])
    mean=[0]*num_of_f
    stddev=[0]*num_of_f
    for line in dataset:
        for j in range(len(line)):
            mean[j]+=line[j]
    
    for i in range(len(mean)):
        mean[i]=mean[i]/float(len(dataset))
    
    for line in dataset:
        for j in range(len(line)):
            stddev[j]+=(line[j]-mean[j])**2
    
    for i in range(len(mean)):
        stddev[i]=(stddev[i]/float(len(dataset)))**0.5
    
    for i in range(len(dataset)):
        for j in range(len(dataset[0])):
            dataset[i][j]=(dataset[i][j]-mean[j])/float(stddev[j])
    
    return dataset

def soft_threshold(a,b):
    if(a<-b/2.0):
        return a+b/2.0
    elif(-b/2.0<=a<=b/2.0):
        return 0
    elif(a>b/2.0):
        return a-b/2.0

def calculate_func(hypo,x):
	
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return temp

if __name__=="__main__":	
    csv_reader= pd.read_csv('AdmissionDataset/data.csv', delimiter=',')
    dataset = [list(x) for x in csv_reader.values]
    dataset=normalize_dataset(dataset)
	
	
    x_data=[]
    y_data=[]
    for i in dataset:
		y_data.append(i[8])
		x_data.append(i[1:8])
	
    x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20)
    x_train=np.array(x_train)	
	
    w_dash =[0,0,0,0,0,0,0] # Making first 3 features significant by setting w for them as non-zero and others zero
    y_pred = x_train.dot(w_dash) + np.random.randn(len(x_train))*0.5 #Setting Y = X.w + some random noise
    
    costs = [] #Setting empty list for costs
    w = np.random.randn(len(x_train[0])) #Setting w to random values
    L1_coeff = 4    
    learning_rate = 0.000081 #Setting learning rate to small value so that the gradient descent algo doesn't skip the minima
    x=[]
    y=[[],[],[],[],[],[],[]]
    y_axis=[]
    for L1_coeff in range(0,40,4):
        for i in range(5000):
            Yhat = x_train.dot(w)
            delta = Yhat - y_pred #the error between predicted output and actual output
            w = w - learning_rate*(x_train.T.dot(delta) + L1_coeff*np.sign(w)) #performing gradient descent for w
            meanSquareError = delta.dot(delta)/len(x_train) #Finding mean square error
            costs.append(meanSquareError) #Appending mse for each iteration in costs list
        
        print("final w:", w) #The final w output. As you can see, first 3 w's are significant , the rest are very small
        x.append(L1_coeff)
        for i in range(len(w)):
            y[i].append(w[i])
        
        y_predi=[]
        for i in x_test:
	   	   y_predi.append(calculate_func(w,i))    
        y_axis.append(get_error(y_test,y_predi))
# plot our w vs true w
    #plt.plot(w_dash, label='true w')
    plt.plot(x,y[0], label='Theta 1')
    plt.plot(x,y[1], label='Theta 2')
    plt.plot(x,y[2], label='Theta 3')
    plt.plot(x,y[3], label='Theta 4')
    plt.plot(x,y[4], label='Theta 5')
    plt.plot(x,y[5], label='Theta 6')
    plt.plot(x,y[6], label='Theta 7')
    
    
    plt.legend()
    plt.show()
