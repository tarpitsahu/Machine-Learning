
import sys
import pandas as pd
import math
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,r2_score
import matplotlib.pyplot as plt
def get_error(y_test,y_pred):
    e=0
    for i in range(len(y_test)):
        e=e+(y_test[i]-y_pred[i])**2
    e=e/float(len(y_test))
    return e

def normalize_dataset(dataset):
    num_of_f=len(dataset[0])
    mean=[0]*num_of_f
    stddev=[0]*num_of_f
    for line in dataset:
        for j in range(len(line)):
            mean[j]+=line[j]
    
    for i in range(len(mean)):
        mean[i]=mean[i]/float(len(dataset))
    
    for line in dataset:
        for j in range(len(line)):
            stddev[j]+=(line[j]-mean[j])**2
    
    for i in range(len(mean)):
        stddev[i]=(stddev[i]/float(len(dataset)))**0.5
    
    for i in range(len(dataset)):
        for j in range(len(dataset[0])):
            dataset[i][j]=(dataset[i][j]-mean[j])/float(stddev[j])
    
    return dataset
def theta_func(parameters,j):
    sum_=0
    for i in parameters:
        sum_+=i*i
    sum_=sum_**0.5
    sum_=sum_/2.0
    sum_=sum_*2*parameters[j]
    
    return sum_
    

def calculate_func(hypo,x):
	temp=0
	for i in range(0,len(hypo)):
		if(i==0):
			temp+=hypo[0]
		else:
			temp+=hypo[i]*x[i-1]
	
	return temp

if __name__=="__main__":	
	csv_reader= pd.read_csv('AdmissionDataset/data.csv', delimiter=',')
	dataset = [list(x) for x in csv_reader.values]
	dataset=normalize_dataset(dataset)
    
	x_data=[]
	y_data=[]
	for i in dataset:
		y_data.append(i[8])
		x_data.append(i[1:8])
	
	x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.20)
	
	
	itr=1
	max_itr=200
	m=len(x_train)
	alpha=0.08
	lambda_=0.1
	y_axis=[]
	xx=[]
	yy=[[],[],[],[],[],[],[],[]]
	random_starters=np.random.randint(low=0,high=10,size=len(x_train[0])+1)
	random_starters=list(random_starters)
	for i in range(len(random_starters)):
		random_starters[i]=float(random_starters[i])
	for lambda_ in range(0,40,4):
	   parameters=[]
	   temp_parameters=[]
	   parameters.extend(random_starters)
	   temp_parameters.extend(random_starters)
	   itr=1
	   while(itr<max_itr):
        		
        		#print "==",lambda_,"==",itr      
        		for i in range(0,len(x_train[0])+1):
        			summation=0
                		
        			for j in range(0,len(x_train)):
        				if(i==0):
        					summation+=(calculate_func(parameters,x_train[j])-y_train[j])
        					
        					
        				else:
        					summation+=((calculate_func(parameters,x_train[j])-y_train[j])*x_train[j][i-1])
        			
        			temp_parameters[i]=parameters[i]-alpha*(1/float(m))*(summation+2*theta_func(parameters,i)*lambda_)		
        			#print temp_parameters
              
        		for ii in range(0,len(x_train[0])+1):
			    parameters[ii]=temp_parameters[ii]+10
		
		
        		itr+=1	
	   #print parameters
	   xx.append(lambda_)
	   for i in range(len(parameters)):
            yy[i].append(parameters[i])
	   y_pred=[]
	   for i in x_test:
	   	   y_pred.append(calculate_func(parameters,i))    
        
	   y_axis.append(get_error(y_test,y_pred))
	   print "Parameters : "
	   for jj in range(len(parameters)):
    		print "Theta ",jj,parameters[jj]
	plt.plot(xx,yy[0], label='Theta 1')
	plt.plot(xx,yy[1], label='Theta 2')
	plt.plot(xx,yy[2], label='Theta 3')
	plt.plot(xx,yy[3], label='Theta 4')
	plt.plot(xx,yy[4], label='Theta 5')
	plt.plot(xx,yy[5], label='Theta 6')
	plt.plot(xx,yy[6], label='Theta 7')
	plt.xlabel("Lambda")
    	plt.ylabel("Parameter Value")
	plt.title("Coefficient vs Lambda : Ridge Regression")
	plt.legend()
	plt.show()
	plt.figure()
	plt.plot(xx,y_axis)
	