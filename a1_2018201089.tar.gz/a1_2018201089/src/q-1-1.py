#!/usr/bin/env python2
# -*- coding: utf-8 -*-

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
import pandas as pd
import matplotlib.pyplot as plt
from math import log


                                                                                                                                                                                                                                                                                                                                    
csv_reader= pd.read_csv('../input_data/train.csv', delimiter=',')
dataset = [list(x) for x in csv_reader.values]

x_train=[]
y_train=[]

def change_dataset(dataset):
    record_len=len(dataset[0])
    for i in xrange(0,len(dataset)):
        if(dataset[i][record_len-1]=='low'):
            dataset[i][record_len-1]=0
        if(dataset[i][record_len-1]=='medium'):
            dataset[i][record_len-1]=1
        if(dataset[i][record_len-1]=='high'):
            dataset[i][record_len-1]=2
            
        if(dataset[i][record_len-2]=='management'):
            dataset[i][record_len-2]=0
        if(dataset[i][record_len-2]=='product_mng'):
            dataset[i][record_len-2]=1
        if(dataset[i][record_len-2]=='technical'):
            dataset[i][record_len-2]=2
        if(dataset[i][record_len-2]=='marketing'):
            dataset[i][record_len-2]=3
        if(dataset[i][record_len-2]=='support'):
            dataset[i][record_len-2]=4
        if(dataset[i][record_len-2]=='IT'):
            dataset[i][record_len-2]=5
        if(dataset[i][record_len-2]=='RandD'):
            dataset[i][record_len-2]=6
        if(dataset[i][record_len-2]=='sales'):
            dataset[i][record_len-2]=7
        if(dataset[i][record_len-2]=='hr'):
            dataset[i][record_len-2]=8
        if(dataset[i][record_len-2]=='accounting'):
            dataset[i][record_len-2]=9
    return dataset
            
dataset=change_dataset(dataset)



for i in dataset:
    x_train.append(i[0:6]+i[7:10])
    y_train.append(i[6]) 

x_train, x_test, y_train, y_test = train_test_split(x_train, y_train, test_size=0.20, random_state=42)    
total_records=len(x_train)
attributes=[5,6,7,8]
importance={}
available_attributes={}

for i in attributes:
    li=[]
    for j in x_train:
        li.append(j[i])
    li=set(li)
    li=list(li)
    li.sort()
    available_attributes[i]=li
    importance[i]=0                                                                                                                                                                        
class Node: 
    # Constructor to create a new node 
    def __init__(self): 
        self.positive = 0 
        self.negative = 0
        self.attribute_number = None
        self.isleaf= 0
        self.child={}
        self.prediction=None
        self.value= None
        self.total_left=0
        self.total_right=0
        self.impurity=0


def calculate_impurity(p,n,impurity_type):
    if(impurity_type==0):
        t=p+n;
        try:
            posi_entropy=(float(p)/t)*(log(float(p)/t)/log(2))
        except:
            posi_entropy=0
        
        try:
            negi_entropy=(float(n)/t)*(log(float(n)/t)/log(2))
        except:
            negi_entropy=0
        
        entropy_of_dataset=-(posi_entropy+negi_entropy)
        return entropy_of_dataset
    elif(impurity_type==1):
        if p+n==0:
             return 0
        return 2*(float(p)/(p+n))*(float(n)/(p+n))
    else:
        if p+n==0:
            return 0
        return min(float(p)/(p+n),float(n)/(p+n))



def create(available_attributes,x_train,y_train,impurity_type):
    global importance
    global total_records
    #print available_attributes,len(x_train),len(y_train)
    mynode=Node()
    for i in y_train:
        if(i==1):
            mynode.positive+=1
        else:
            mynode.negative+=1
    
    entropy_of_dataset=calculate_impurity(mynode.positive,mynode.negative,impurity_type)
    mynode.impurity=entropy_of_dataset
    #print mynode.positive,mynode.negative
    if(len(available_attributes)==0 or mynode.positive==0 or mynode.negative==0):
        mynode.isleaf=1
    flag=0
    for i in available_attributes:
        if(len(available_attributes[i])>1):
            flag=1
            break
        
    if(flag==0):
        mynode.isleaf=1
    
        
    if(mynode.isleaf==1):
        if(mynode.positive>mynode.negative):
            mynode.prediction=1
        else:
            mynode.prediction=0;
        mynode.attribute_number="leaf"
        return mynode
    
    
    ## Entropy of Table Distribution
    
    #print "=",entropy_of_dataset

    
    ## Entropy of Attribute
    max_gain=0
    best_attribute=None
    best_threshold=None
    #print available_attributes,"=="
    for attr in available_attributes:
        if(len(available_attributes[attr])==1):
            continue
        
        
        for i in xrange(0,len(available_attributes[attr])-1):
           avg_entropy=0
           threshold=(available_attributes[attr][i]+available_attributes[attr][i+1])/2;
           for j in range(0,2): 
               p=0
               n=0
               t=0
               for k in range(0,len(x_train)):
                   if(j==0):
                       if x_train[k][attr]<threshold and y_train[k]==1:
                           p+=1;
                       elif x_train[k][attr]<threshold and y_train[k]==0:
                           n+=1;
                   if(j==1):
                       if x_train[k][attr]>=threshold and y_train[k]==1:
                           p+=1;
                       elif x_train[k][attr]>=threshold and y_train[k]==0:
                           n+=1;
               entropy_of_attr_val=calculate_impurity(p,n,impurity_type)
               t=p+n
               #print val,t,p,n,entropy_of_attr_val,"\n"
               #print "@ ",len(x_train)," ",t
               avg_entropy+=(float(t)/len(x_train))*entropy_of_attr_val
           #print attr," ",avg_entropy," ",entropy_of_dataset-avg_entropy
           if(entropy_of_dataset-avg_entropy > max_gain):
                    max_gain=entropy_of_dataset-avg_entropy
                    best_attribute=attr;
                    best_threshold=threshold
    if(best_attribute==None):
        mynode.isleaf=1
        if(mynode.positive>mynode.negative):
            mynode.prediction=1
        else:
            mynode.prediction=0;
        mynode.attribute_number="leaf"
        return mynode
        
    
    #print "Best Attribute is : ",best_attribute
    mynode.attribute_number=best_attribute
    mynode.value=best_threshold
    #print "Attribute",best_attribute
    #print "threshold",best_threshold
    
    
    for val in range(0,2):
        if(val==0):
            new_x_train=[]
            new_y_train=[]
            for i in range (0,len(x_train)):
                if x_train[i][best_attribute]<best_threshold:
                    new_x_train.append(x_train[i])
                    new_y_train.append(y_train[i])
            temp_available_attributes={}
            for attr in available_attributes:
                if(attr!=best_attribute):
                    #print attr
                    temp_available_attributes[attr]=available_attributes[attr]
                else:
                    temp_available_attributes[attr]=[]
                    for i in available_attributes[attr]:
                        if(i<best_threshold):
                            temp_available_attributes[attr].append(i)
                            
        
            #print temp_available_attributes[0],"\n\n"
            mynode.total_left=len(new_x_train)
            mynode.child[0]=create(temp_available_attributes,new_x_train,new_y_train,impurity_type)
        if(val==1):
            new_x_train=[]
            new_y_train=[]
            for i in range (0,len(x_train)):
                if x_train[i][best_attribute]>=best_threshold:
                    new_x_train.append(x_train[i])
                    new_y_train.append(y_train[i])
            temp_available_attributes={}
            for attr in available_attributes:
                if(attr!=best_attribute):
                    temp_available_attributes[attr]=available_attributes[attr]
                else:
                    temp_available_attributes[attr]=[]
                    for i in available_attributes[attr]:
                        if(i>=best_threshold):
                            temp_available_attributes[attr].append(i)
        
            #print temp_available_attributes[0],"\n\n"
            #print temp_available_attributes   
            mynode.total_right=len(new_x_train)
            mynode.child[1]=create(temp_available_attributes,new_x_train,new_y_train,impurity_type)
    total_samples=mynode.positive+mynode.negative
    importance[mynode.attribute_number]+=(float(total_samples)/total_records)*(entropy_of_dataset - float(mynode.total_left)/total_samples*mynode.child[0].impurity -float(mynode.total_right)/total_samples*mynode.child[1].impurity )
    return mynode         
            

def make_prediction(root,data):
    #print root.attribute_number
    if(root.isleaf==1):
        #print "here"
        return root.prediction
    else:
        #print "there"
        data_value=data[root.attribute_number]
        if(data_value<root.value):
            root=root.child[0]
        else:
            root=root.child[1]
        return make_prediction(root,data)
	
def perf_measure(y_actual, y_hat):
    TP = 0
    FP = 0
    TN = 0
    FN = 0

    for i in range(len(y_hat)): 
        if y_actual[i]==y_hat[i]==1:
           TP += 1
        if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
           FP += 1
        if y_actual[i]==y_hat[i]==0:
           TN += 1
        if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
           FN += 1

    print TP, FP, TN, FN





def analyze_results(y_test,y_pred,k):    
	accuracy_list=[]
	precision_list=[]
	recall_list=[]
	f1_list=[]
	global importance

	
		
	if(k==0):
		msg="Impurity Candidate : Entropy"
	if(k==1):
		msg="Impurity Candidate : Gini Index"
	if(k==2):
		msg="Impurity Candidate : Misclassification Rate"

	print msg
	print "Accuracy",accuracy_score(y_test, y_pred)
	print "Recall",recall_score(y_test, y_pred)
	print "Precision",precision_score(y_test, y_pred)
	print "F1-Score",f1_score(y_test, y_pred)
	print "\n\n"
	accuracy_list.append(accuracy_score(y_test, y_pred))
	precision_list.append(precision_score(y_test, y_pred))
	recall_list.append(recall_score(y_test, y_pred))
	f1_list.append(f1_score(y_test, y_pred))
	
	return accuracy_list,precision_list,recall_list,f1_list
	

   
def predict(X):
	X=change_dataset(X)
	y_pred=[]
	for i in range(0,len(X)):
	    y_pred.append(make_prediction(treeroot,X[i]))
	return y_pred



###########################################################
#Training Part
impurity_parameter=2		#0:Entropy 1:Ginni 2 Miscll
treeroot=create(available_attributes,x_train,y_train,impurity_parameter)
y_pred=predict(x_test)
analyze_results(y_test,y_pred,impurity_parameter)


#Testing Part
csv_reader_2= pd.read_csv('../input_data/sample_test.csv', delimiter=',')
x_test = [list(x) for x in csv_reader_2.values]
y_pred=predict(x_test)


	
