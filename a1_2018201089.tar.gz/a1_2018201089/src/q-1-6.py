print "Strategy 1 : Incase of Categorical data, Associate a branch with missing data i.e. whenever you find a missing value TAKE A SPECIFIC branch and proceed further. "
print ""
print "Strategy 2 : Incase of Numerical data, Associate the missing data with branch that has LEAST ERROR and proceed further."
print ""
print "Strategy 3 : Throw away the records that contain missing data, and proceed normally. (if missing not random, throwing away cases can bias sample towards certain kinds of cases)"
print ""
print "Strategy 4 : Mean imputation : Calculate the mean of the observed values for that variable for all individuals who are non-missing." 
print ""
print "Strategy 5 : Hot Deck Imputation : A randomly chosen value from an individual in the sample who has similar values on other variables. In other words, find all the sample subjects who are similar on 							other variables, then randomly choose one of their values on the missing variable."
print ""
print "Strategy 6 : Regression imputation : The predicted value obtained by regressing the missing variable on other variables."
print ""
print "Strategy 7 : Interpolation and extrapolation : An estimated value from other observations from the same individual."
print ""
 

			