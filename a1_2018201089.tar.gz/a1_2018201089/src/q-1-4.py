#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 15 18:00:14 2019

@author: tarpitsahu
"""

import pandas as pd
import matplotlib.pyplot as plt

plt.figure()
csv_reader= pd.read_csv('../input_data/train.csv', delimiter=',')
dataset = [list(x) for x in csv_reader.values]


x=[]
y=[]
for i in dataset:
    if(i[6]==0):
        x.append(i[0])
        y.append(i[2])
good=plt.scatter(x,y,color='green',marker='*')
       

x=[]
y=[]
for i in dataset:
    if(i[6]==1):
        x.append(i[0])
        y.append(i[2])
bad=plt.scatter(x,y,color='red',marker='x')


plt.legend((good, bad),
           ('Employee Retained', 'Employee Left'),
           scatterpoints=1,
           loc='upper left',
           ncol=1,
           fontsize=8)
plt.suptitle('Upset Employee Classification', fontsize=13)
plt.xlabel('Satisfaction Level', fontsize=8)
plt.ylabel('Number of Projects', fontsize=8)
plt.show()
plt.savefig('satis vs number of projects')



