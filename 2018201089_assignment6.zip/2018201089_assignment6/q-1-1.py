#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  4 14:49:23 2019

@author: mypc
"""
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
def rgb2gray(rgb):
    return np.dot(rgb[...,:3], [0.299, 0.587, 0.114])


def tanh(Z):
    temp1=np.exp(Z)-np.exp(-Z)
    temp2=np.exp(Z)+np.exp(-Z)
    return temp1/temp2


def sigmoid(Z):
    temp = 1 + np.exp(-Z)
    return 1./temp


def relu(Z):
    return Z*np.where(Z >= 0 , 1 , 0)

def leakyrelu(Z):
    return Z*np.where(Z >= 0 , 1 , 0.01)

def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()


class my_neural_network():
    def __init__(self):
        self.filter1=[]
        self.layer1=[]
        self.pool1=[]
        self.filter2=[]
        self.layer2=[]
        self.pool2=[]
        self.filter3=[]
        self.layer3=[]
        
        self.input=[]
        self.fc1=[]
        self.output=[]
        
        self.weights1=np.random.rand(120,84)
        self.weights2=np.random.rand(84,10)
        self.bias1=np.random.rand(1,84)
        self.bias2=np.random.rand(1,10)



        for i in range(6):
            self.filter1.append(np.random.rand(1,5,5))
        for i in range(16):
            self.filter2.append(np.random.rand(6,5,5))
        for i in range(120):
            self.filter3.append(np.random.rand(16,5,5))
        
        
        self.fc1.append(np.random.rand(84))
        
        
        
    def convolution_function(self,matrix,fil):
        matrix_depth,matrix_rows,matrix_cols=matrix.shape
        filter_depth,filter_rows,filter_cols=fil.shape
        convolved_map=[]
        for i in range(0,matrix_rows-filter_rows+1):
            temp=[]
            for j in range(0,matrix_cols-filter_cols+1):
                fr=matrix[:,i:i+5,j:j+5]
                ans=self.convolve(fr,fil,matrix_depth)
                temp.append(ans)
            convolved_map.append(temp)
        return np.array(convolved_map)
    
    
    def convolve(self,fr,fil,d):
        sum_=0
        
        for i in range(d):
            
            fr_=np.array(fr[i])
            fil_=np.array(fil[i])
            sum_+=np.sum(np.multiply(fr_,fil_))
        
        
        return leakyrelu(sum_)
    
    def pooling(self,matrix,pool_x,pool_y):
        matrix_depth,matrix_rows,matrix_cols=matrix.shape
        pooling_layer=[]
        for depth in range(matrix_depth):
            final=[]
            
            for i in range (0,matrix_rows-pool_x+1,pool_x):
                temp=[]
                for j in range (0,matrix_cols-pool_y+1,pool_y):
                    temp.append(np.min(matrix[depth,i:i+pool_x,j:j+pool_y]))
                final.append(temp)
            pooling_layer.append(final)
        
        return np.array(pooling_layer)




img = Image.open('ten.png').convert('L')
img = img.resize((32,32), Image.ANTIALIAS)
img.save('greyscale.jpg')

img = Image.open('greyscale.jpg')
img=np.array(img)

#for i in range(32):
#    for j in range(32):
#        if img[i][j]>30:
#            img[i][j]=0
#im=Image.fromarray(im)
#img.show()

img=img.reshape(1,32,32)

#img=np.random.rand(1,32,32)
cnn=my_neural_network()

for i in range(6):
    cnn.layer1.append(cnn.convolution_function(img,cnn.filter1[i]))

cnn.layer1=np.array(cnn.layer1)
print cnn.layer1.shape

cnn.pool1=cnn.pooling(cnn.layer1,2,2)
print cnn.pool1.shape



for i in range(16):
    cnn.layer2.append(cnn.convolution_function(cnn.pool1,cnn.filter2[i]))

cnn.layer2=np.array(cnn.layer2)
print cnn.layer2.shape


cnn.pool2=cnn.pooling(cnn.layer2,2,2)
print cnn.pool2.shape

for i in range(120):
    cnn.layer3.append(cnn.convolution_function(cnn.pool2,cnn.filter3[i]))

cnn.layer3=np.array(cnn.layer3)
print cnn.layer3.shape
a,b,c=cnn.layer3.shape


fig = plt.figure()
for i in range(6):
    plt.subplot(2,3,i+1)
    plt.title("C1 Filter"+str(i+1))
    plt.imshow(cnn.layer1[i],cmap='gray')

plt.savefig("Layer1_LEAKYRELU")
    
    
fig = plt.figure()
plt.tight_layout()
for i in range(16):
    plt.subplot(3,6,i+1)
    plt.title("C3 Filter"+str(i+1),fontsize=8)
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=5)
    plt.imshow(cnn.layer2[i],cmap='gray')
plt.savefig("Layer2_LEAKYRELU")
fig = plt.figure()
plt.tight_layout()
for i in range(120):
    plt.subplot(9,14,i+1)
    plt.xticks(fontsize=4)
    plt.yticks(fontsize=4)
    
    plt.imshow(cnn.layer3[i],cmap='gray')
plt.savefig("Layer3_LEAKYRELU")
plt.show()
cnn.input=cnn.layer3.reshape(a*b*c,1)

cnn.input=cnn.input.T


cnn.fc1=np.dot(cnn.input,cnn.weights1)+cnn.bias1
cnn.fc1=leakyrelu(cnn.fc1)


cnn.output=np.dot(cnn.fc1,cnn.weights2)+cnn.bias2
print cnn.output
cnn.output=softmax(cnn.output)



