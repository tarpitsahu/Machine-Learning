#!/usr/bin/env python
# coding: utf-8

# # Assignment 5
# # Implementation of Neural Network
# 
# Submitted by : Tarpit Sahu<br>
# roll no : 2018201051
# 

# ## Question 1 : Train and validate your own n-layer Neural Network on the Apparel dataset to predict the class label of a given apparel. You are free to choose the hyper-parameters, training strategy to handle large number of training data (Hint: Batch Size) architecture - number of hidden layers, number of nodes in each hidden layer etc.

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[ ]:


def sigmoid(Z):
    temp = 1 + np.exp(-Z)
    return 1./temp


# In[ ]:


def relu(Z):
    return Z*np.where(Z >= 0 , 1 , 0)


# In[ ]:


def softmax(Z):
    return np.divide(np.exp(Z) ,np.sum(temp , axis = 0), dtype = "float")


# In[ ]:


def y_transform(y):
    arr =  []
    for i  in range(y.shape[0]):
        temp=[]
        for i in range(10):
            temp.append(0)
        val = y.iloc[i]
        temp[val] = 1 
        arr.append(temp)
    arr = np.array(arr)
    return arr.T


# In[1]:


def linear_backward( dZ , A_prev , W):
    m = A_prev.shape[1]
    dW = np.dot(dZ, A_prev.T)/m
    db = np.sum(dZ, axis = 1, keepdims = True)/m
    dA_prev = np.dot(W.T, dZ)
    return dA_prev , db , dW

def relu_backward( dA , Z):
    return dA*np.where(Z >= 0 , 1 ,0)

def sig_backward( dA , Z):
    return dA*sigmoid(Z)*(1-sigmoid(Z))


# In[2]:


class my_neural_network():
    def __init__(self,  dimensions = [] , fun = [] ,iterations = 30, learning_rate = 0.1):
        self.num_iters = iterations
        self.num_layers = len(dims)-1
        self.weights={}
        self.bias={}
        self.functions={}
        self.val_error = []
        
        for i in range(1, self.num_layers +1):
            weight_str="w" + str(i)
            self.weights[weight_str] = np.random.randn(dimensions[i],dimensions[i-1])
            bias_str="b"+str(i)
            self.bias[bias_str] = np.zeros((dimensions[i] , 1))
           
    
    def forward_propagation(self,X) :
        caches  = []
        old_layer  =  X
        for i  in range(1, self.num_layers + 1) :
            weight_str="w"+str(i)
            bias_str="b"+str(i)
            func_str="acti"+str(i)
            
            
            
            temp  = np.matmul(self.weights[weight_str], old_layer) 
            Z  = temp  +  self.bias[bias_str]
            
            if self.functions[func_str] == "relu" :
                new_layer = relu(Z)
                
            elif self.functions[func_str] == "sigmoid":
                new_layer = sigmoid(Z)

            elif self.functions[func_str] == "softmax":
                new_layer = softmax(Z)
            
            cache = (old_layer, Z)
            caches.append(cache)
            old_layer = new_layer
        return new_layer, caches
    
    def backward_propagation(self):
        loss = error(self.a[self.hiddenLayers+1], self.y)

        self.da[self.hiddenLayers+1] = cross_entropy(self.a[self.hiddenLayers+1], self.y) # w3
        for i in range(self.hiddenLayers,0,-1):
            self.dz[i] = np.dot(self.da[i+1], self.w[i+1].T)
            self.da[i] = self.dz[i] * ReLU_derv(self.a[i])
       
        self.w[self.hiddenLayers+1] -= self.lr * np.dot(self.a[self.hiddenLayers].T, self.da[self.hiddenLayers+1])
        self.b[self.hiddenLayers+1] -= self.lr * np.sum(self.da[self.hiddenLayers+1], axis=0, keepdims=True)
        for i in range(self.hiddenLayers,1,-1):
            self.w[i] -= self.lr * np.dot(self.a[i-1].T, self.da[i])
            self.b[i] -= self.lr * np.sum(self.da[i], axis=0)
        self.w[1] -= self.lr * np.dot(self.x.T, self.da[1])
        self.b[1] -= self.lr * np.sum(self.da[1], axis=0)
            
        
    def update_weights(self, gradients):
        for l in range(self.num_layers):
            weight_str="w"+str(l+1)
            bias_str="b"+str(l+1)
            self.weights[weight_str] =self.weights[weight_str] -self.learning_rate*gradients["d"+weight_str]
            self.bias[bias_str] = self.bias[bias_str] -self.learning_rate*gradients["b"+bias_str]

    def fit(self , X, Y ,val_X , val_Y,  batch_size = 5000):
        l = X.shape[0]/batch_size
        
        val_X = val_X.astype('float')/255
        val_Y = y_transform(val_Y)
        
        for  i in range(self.num_iters):
            print("Epoch ========== " + str(i)+" :=========== ")
            cost = 0
            for i in np.arange(2,self.hiddenLayers+1):
                self.w[i] = np.random.randn(self.neurons, self.neurons)
                self.b[i] = np.zeros((1, self.neurons))
            self.w[self.hiddenLayers+1] = np.random.randn(self.neurons, self.op_dim)
            self.b[self.hiddenLayers+1] = np.zeros((1, self.op_dim))

            self.training_error.append(float(cost)/X.shape[0])
            
            #Calculating validation error
            al_val, _ = self.forward_propagation(val_X.T)
            val_e  = float(self.error(al_val,val_Y))/val_X.shape[0]
            self.val_error.append(val_e)
            print("training error is  " + str(float(cost)/X.shape[0]))
            print("val error is : " + str(val_e))
    
    def error(self, al ,  y ):
        n_max =  np.max(al  ,axis = 0 )
        result =  np.where(al >=n_max , 1 , 0)
        cost  = np.sum(np.sum(np.abs(result-y) , axis  = 0)/2)
        return float(cost)
    
    
    def predict(self , X):
        X = X.astype('float')/255
#         y = y_transform(y)
        al, caches = self.forward_propagation(X.T)
        n_max =  np.max(al  ,axis = 0)
        result =  np.where(al >=n_max , 1 , 0)
        temp =  np.array([0,1,2,3,4,5,6,7,8,9]).reshape(10,1)
        n_max2 = np.max(result*temp,axis = 0)
        return n_max2
                
#         


# In[ ]:


# # from google.colab import files
# # files.upload()
# !unzip data.zip
# !ls


# ##  Loading Apparel dataset

# In[ ]:


data = pd.read_csv('data.csv')
data.head()
train_data = data.iloc[:50000,:]
val_data = data.iloc[50000:,:]


# In[ ]:


train_X = train_data.iloc[: , 1:]
train_Y = train_data.iloc[: , 0]
val_X = val_data.iloc[:,1:]
val_Y = val_data.iloc[:,0]


# ## Some examples 

# ###  Training a neural network with 2 hidden layers and sigmoid function   

# In[ ]:


NN = neuralNet([784 ,300, 100 , 10] ,['sigmoid', 'sigmoid' , 'softmax'] , iterations = 50)


# In[18]:


test_result = NN.predict(val_X)
print(test_result)


# In[19]:


NN.epoch_vs_accuracy()


# In[ ]:


### Training with relu function 


# In[24]:


NN1.epoch_vs_accuracy()


# ### Training with Sigmoid 

# In[ ]:


NN3 = neuralNet([784 ,1024, 10] ,['sigmoid' , 'softmax'] , iterations = 50 , learning_rate = 0.1)


# In[30]:


NN3.fit(train_X,  train_Y , val_X , val_Y , 100)


# In[32]:


NN3.epoch_vs_accuracy()


# ## Question 2 :  

# ### Requirments for the data set of house price prediction :  

# ```
# 1 . only one node will be enough in the output layer since it is a regression problem .
# 2 . Required linear activation function in the output layer(need to modifiy as softmax is used in above 
#     neural network) .
# 3 . All hidden layers should not have linear activation function since it will be unable to learn 
#     nonlinearity in the data because 3 hidden layers with all linear activation will work the same way 
#     as a single layer neural network. 
# 4 . cost function should also be changed.(ex : least mean square can be used. )
# ```
